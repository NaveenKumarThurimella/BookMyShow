package com.naveen.MovieApi.Repository;

import java.time.LocalDate;
import java.util.List;
import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;

import com.naveen.MovieApi.Entity.Movie;

public interface MovieRepository extends JpaRepository<Movie,Integer>{

	List<Movie> findByGenere(String genere);

	List<Movie> findByLanguage(String language);
	
	Movie findByNameAndReleaseDate(String name, LocalDate releaseDate);

	Optional<Movie> findById(Integer id);
	
	
}
