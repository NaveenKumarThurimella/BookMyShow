package com.naveen.MovieApi.Exception;

public class NoGenreException extends RuntimeException {
	
	private static final long serialVersionUID = 1L;

	public NoGenreException(String message)  {
		  super(message);
	  }

	
	

}
