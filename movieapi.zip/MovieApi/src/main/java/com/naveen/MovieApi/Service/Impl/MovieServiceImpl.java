
package com.naveen.MovieApi.Service.Impl;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import com.naveen.MovieApi.Entity.Movie;
import com.naveen.MovieApi.Entity.Show;
import com.naveen.MovieApi.Entity.Theatre;
import com.naveen.MovieApi.Exception.NoLanguageException;
import com.naveen.MovieApi.Repository.MovieRepository;
import com.naveen.MovieApi.Service.MovieService;

@Service
public class MovieServiceImpl implements MovieService {

	@Autowired
	private MovieRepository repository;

	@Autowired
	private RestTemplate restTemplate;

	public static final String urlForTheatreInfo = "http://localhost:8087/theatre/";

	public static final String urlForMovieInfo = "http://localhost:8086/movie/";

	public static final String urlForShowInfo = "http://localhost:8088/show/";

	@Override
	public Movie saveMovie(Movie movie) {
		return repository.save(movie);
	}

	@Override
	public List<Movie> getMovieByGenere(String city, String genere) {
		
		List<Movie> movie = new ArrayList<Movie>();
		List<Movie> movies = new ArrayList<Movie>();
		Movie movieData = null;
		Movie movieDesc = null;
		List<Integer> movieIds = new ArrayList<Integer>();
		Theatre[] theatres = restTemplate.getForEntity(urlForTheatreInfo + city, Theatre[].class).getBody();
		for (Theatre t : theatres) {
			Show[] shows = restTemplate.getForEntity(urlForShowInfo + t.getTid(), Show[].class).getBody();
			for (Show s : shows) {
				 movieIds.add(s.getMovieid());
			}
		}
		 for(Integer m : movieIds)
		 {
		 movieDesc = restTemplate.getForEntity(urlForMovieInfo +m.intValue(), Movie.class).getBody();
		 movies.add(movieDesc);
		 }
		for (Movie m : movies) {
			if (m.getGenere().equalsIgnoreCase(genere)) {
				movieData = restTemplate.getForEntity(urlForMovieInfo + m.getId(), Movie.class).getBody();
				movie.add(movieData);
			}
		}
		if (movie.size() == 0) {
			throw new NoLanguageException(
					"There is no Movies running in the city " + city + " with the genere " + genere);
		}
		return movie;

	}
		

	@Override
	public List<Movie> getMovieByLanguage(String city, String language) {
		List<Movie> movie = new ArrayList<Movie>();
		List<Movie> movies = new ArrayList<Movie>();
		Movie movieData = null;
		Movie movieDesc = null;
		List<Integer> movieIds = new ArrayList<Integer>();
		Theatre[] theatres = restTemplate.getForEntity(urlForTheatreInfo + city, Theatre[].class).getBody();
		for (Theatre t : theatres) {
			Show[] shows = restTemplate.getForEntity(urlForShowInfo + t.getTid(), Show[].class).getBody();
			for (Show s : shows) {
				 movieIds.add(s.getMovieid());
			}
		}
		 for(Integer m : movieIds)
		 {
		 movieDesc = restTemplate.getForEntity(urlForMovieInfo +m.intValue(), Movie.class).getBody();
		 movies.add(movieDesc);
		 }
		for (Movie m : movies) {
			if (m.getLanguage().equalsIgnoreCase(language)) {
				movieData = restTemplate.getForEntity(urlForMovieInfo + m.getId(), Movie.class).getBody();
				movie.add(movieData);
			}
		}
		if (movie.size() == 0) {
			throw new NoLanguageException(
					"There is no Movies running in the city " + city + " with the language " + language);
		}
		return movie;

	}

	@Override
	public Movie findByNameAndReleaseDate(String name, LocalDate releaseDate) {
		return repository.findByNameAndReleaseDate(name, releaseDate);
	}

	@Override
	public List<Movie> getAllMovies() {
		return repository.findAll();
	}

	@Override
	public Optional<Movie> getMovieById(@Valid Integer id) {
		return repository.findById(id);
	}
	

	@Override
	public List<Movie> getMoviesByCity(String city) {
		List<Movie> movies = new ArrayList<Movie>();
		Movie movieDesc = null;
		Theatre[] theatres = restTemplate.getForEntity(urlForTheatreInfo + city, Theatre[].class).getBody();
		for (Theatre t : theatres) {
			Show[] shows = restTemplate.getForEntity(urlForShowInfo + t.getTid(), Show[].class).getBody();
			for (Show s : shows) {
				movieDesc = restTemplate.getForEntity(urlForMovieInfo + s.getMovieid(), Movie.class).getBody();
				movies.add(movieDesc);
			}
		}
		return movies;
	}

}
