package com.naveen.MovieApi.Entity;

import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

import lombok.AllArgsConstructor;
import lombok.NoArgsConstructor;

@Entity
@NoArgsConstructor
@AllArgsConstructor
@Table(name="Theatre")
public class Theatre {
	
	@Id
	@GeneratedValue(strategy = GenerationType.SEQUENCE,generator = "tid_generator")
	@SequenceGenerator(name="tid_generator",initialValue = 1,allocationSize = 1,sequenceName = "tid_seq")
		private Integer tid;
	
    @Column(name="T_Name")
	private String name;
    
    @ManyToOne(targetEntity = City.class, cascade = CascadeType.ALL)
    @JoinColumn(name = "Theatre_fk1_City_Id", referencedColumnName = "id")
     private City city;
    
    
    @OneToMany(targetEntity = Screens.class, cascade = CascadeType.ALL)
    @JoinColumn(name = "Theatre_fk_Screens_", referencedColumnName = "tid")
    private List<Screens> screens;


	public Integer getTid() {
		return tid;
	}


	public void setTid(Integer tid) {
		this.tid = tid;
	}


	public String getName() {
		return name;
	}


	public void setName(String name) {
		this.name = name;
	}


	public City getCity() {
		return city;
	}


	public void setCity(City city) {
		this.city = city;
	}


	public List<Screens> getScreens() {
		return screens;
	}


	public void setScreens(List<Screens> screens) {
		this.screens = screens;
	}
	
    
	
}
