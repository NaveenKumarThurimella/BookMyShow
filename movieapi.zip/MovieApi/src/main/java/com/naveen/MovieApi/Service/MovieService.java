package com.naveen.MovieApi.Service;

import java.time.LocalDate;
import java.util.List;
import java.util.Optional;

import javax.validation.Valid;

import org.springframework.stereotype.Service;

import com.naveen.MovieApi.Entity.Movie;

@Service
public interface MovieService {

	Movie saveMovie(Movie movie);

	List<Movie> getMovieByGenere(String city, String genere);

	List<Movie> getMovieByLanguage(String city, String language);

	Movie findByNameAndReleaseDate(String name, LocalDate releaseDate);

	List<Movie> getAllMovies();

	Optional<Movie> getMovieById(Integer id);
	
	List<Movie> getMoviesByCity(String city);

}
