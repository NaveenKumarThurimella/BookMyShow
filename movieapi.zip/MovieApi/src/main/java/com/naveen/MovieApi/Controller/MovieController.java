package com.naveen.MovieApi.Controller;

import java.util.List;
import java.util.Optional;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.naveen.MovieApi.Entity.Movie;
import com.naveen.MovieApi.Exception.ResourceNotFoundException;
import com.naveen.MovieApi.Service.MovieService;

@RestController
public class MovieController {

	@Autowired
	private MovieService service;


	@PostMapping("/addMovie")
	public ResponseEntity<Movie> addMovie(@Valid @RequestBody Movie movie) {
		Movie m = service.findByNameAndReleaseDate(movie.getName(), movie.getReleaseDate());
		if (m == null) {
			return new ResponseEntity<Movie>(service.saveMovie(movie), HttpStatus.CREATED);
		} else {
			// throw new RuntimeException("Movie with this name and releaseDate are already
			// existed");
			throw new ResourceNotFoundException("Movie with this name and releaseDate are already existed");
		}
	}

	@GetMapping("/movie/language/{city}/{language}")
	public ResponseEntity<List<Movie>> findMovieByLanguage(@Valid @PathVariable String city,@Valid @PathVariable String language) {
		return new ResponseEntity<List<Movie>>(service.getMovieByLanguage(city, language), HttpStatus.OK);
	}

	@GetMapping("/movie/genere/{city}/{genere}")
	public ResponseEntity<List<Movie>> findMovieByGenere(@Valid @PathVariable String city, @Valid @PathVariable String genere) {
				return new ResponseEntity<List<Movie>>(service.getMovieByGenere(city, genere), HttpStatus.OK);
			
	}

	
	@GetMapping("/movie/{id}")
	public ResponseEntity<Optional<Movie>> getById(@Valid @PathVariable Integer id)
	{
		return new ResponseEntity<Optional<Movie>>(service.getMovieById(id),HttpStatus.OK);
	}
	
	@GetMapping("/movie/city/{city}")
	public ResponseEntity<List<Movie>> getMoviesBycity(@Valid @PathVariable String city)
	{
		return new ResponseEntity<List<Movie>>(service.getMoviesByCity(city),HttpStatus.OK);
	}

}
