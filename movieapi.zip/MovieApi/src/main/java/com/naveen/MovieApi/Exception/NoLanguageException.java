package com.naveen.MovieApi.Exception;

public class NoLanguageException  extends RuntimeException {
	
	private static final long serialVersionUID = 1L;

	public NoLanguageException(String message)  {
		  super(message);
	  }


}
