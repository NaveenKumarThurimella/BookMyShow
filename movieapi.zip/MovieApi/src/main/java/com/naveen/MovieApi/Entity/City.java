package com.naveen.MovieApi.Entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

import lombok.AllArgsConstructor;
import lombok.NoArgsConstructor;

@Entity
@NoArgsConstructor
@AllArgsConstructor
@Table(name = "City")
public class City {

	@Id
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "cid_generator")
	@SequenceGenerator(name = "cid_generator", initialValue = 10, allocationSize = 1, sequenceName = "cid_seq")
	private Integer id;

	@Column(name = "city_name")
	private String cityName;

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public String getCityName() {
		return cityName;
	}

	public void setCityName(String cityName) {
		this.cityName = cityName;
	}
	
   

}