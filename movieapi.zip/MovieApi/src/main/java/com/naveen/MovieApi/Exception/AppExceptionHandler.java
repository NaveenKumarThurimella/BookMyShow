package com.naveen.MovieApi.Exception;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.servlet.mvc.method.annotation.ResponseEntityExceptionHandler;

import com.naveen.MovieApi.Exception.NoGenreException;
import com.naveen.MovieApi.Exception.NoLanguageException;
import com.naveen.MovieApi.Exception.ResourceNotFoundException;

@org.springframework.web.bind.annotation.ControllerAdvice
public class AppExceptionHandler extends ResponseEntityExceptionHandler {
	@ExceptionHandler
	public ResponseEntity<String> handlerResourceNotFoundException(ResourceNotFoundException ex){
	 return new ResponseEntity<String>(ex.getMessage(), HttpStatus.BAD_REQUEST);
	 
	}
	
	@ExceptionHandler
	public ResponseEntity<String> handlerNoLanguageException(NoLanguageException ex){
	 return new ResponseEntity<String>(ex.getMessage(), HttpStatus.BAD_REQUEST);
	 
	}
	
	@ExceptionHandler
	public ResponseEntity<String> handlerNoGenreException(NoGenreException ex){
	 return new ResponseEntity<String>(ex.getMessage(), HttpStatus.BAD_REQUEST);
	 
	}



}
