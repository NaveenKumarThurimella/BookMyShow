package com.naveen.MovieApi.Entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

import lombok.AllArgsConstructor;
import lombok.NoArgsConstructor;

@Entity
@NoArgsConstructor
@AllArgsConstructor
@Table(name = "Screens")
public class Screens {
	@Id
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "scid_generator")
	@SequenceGenerator(name = "scid_generator", initialValue = 100, allocationSize = 1, sequenceName = "scid_seq")
	private Integer scid;

	@Column(name = "S_No")
	private Integer screenNumber;

	@Column(name = "No_Of_Shows")
	private Integer shows;

	@Column(name = "No_Of_Seats")
	private Integer seats;

	public Integer getScid() {
		return scid;
	}

	public void setScid(Integer scid) {
		this.scid = scid;
	}

	public Integer getScreenNumber() {
		return screenNumber;
	}

	public void setScreenNumber(Integer screenNumber) {
		this.screenNumber = screenNumber;
	}

	public Integer getShows() {
		return shows;
	}

	public void setShows(Integer shows) {
		this.shows = shows;
	}

	public Integer getSeats() {
		return seats;
	}

	public void setSeats(Integer seats) {
		this.seats = seats;
	}

}
