package com.naveen.TheatreApi.Service;

public interface ScreensService {

	
}
