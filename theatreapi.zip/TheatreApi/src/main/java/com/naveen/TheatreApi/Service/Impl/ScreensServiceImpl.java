package com.naveen.TheatreApi.Service.Impl;

import org.springframework.stereotype.Service;

import com.naveen.TheatreApi.Service.ScreensService;
@Service
public class ScreensServiceImpl implements ScreensService {

}
