package com.naveen.TheatreApi.Exception;

public class DuplicateTheatreException extends RuntimeException {

	private static final long serialVersionUID = 1L;
  
	private String message;
	public DuplicateTheatreException(String message) {
		super(message);
		this.message=message;
	}
	@Override
	public String toString() {
		return message;
	}
	
	
}
