package com.naveen.TheatreApi.Service;

import org.springframework.stereotype.Service;

import com.naveen.TheatreApi.Entity.City;

@Service
public interface CityService {

	 City addCity(City city);
}
