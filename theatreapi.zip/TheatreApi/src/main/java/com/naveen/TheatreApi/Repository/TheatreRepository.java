package com.naveen.TheatreApi.Repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.naveen.TheatreApi.Entity.Theatre;

@Repository
public interface TheatreRepository extends JpaRepository<Theatre,Integer>{
	
	Theatre findByName(String name);

	@Query("FROM Theatre t JOIN t.city c WHERE c.cityName= :cityName")
	List<Theatre> findTheatreByCityName(@Param(value = "cityName") String cityName);
	
	

}
