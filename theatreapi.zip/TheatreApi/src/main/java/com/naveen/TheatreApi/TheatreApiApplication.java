package com.naveen.TheatreApi;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class TheatreApiApplication {

	public static void main(String[] args) {
		SpringApplication.run(TheatreApiApplication.class, args);
	}

}
