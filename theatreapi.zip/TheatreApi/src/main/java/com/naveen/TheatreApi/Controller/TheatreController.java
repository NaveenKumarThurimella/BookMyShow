package com.naveen.TheatreApi.Controller;

import java.util.List;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.naveen.TheatreApi.Entity.Theatre;
import com.naveen.TheatreApi.Service.TheatreService;

@RestController
public class TheatreController {
	@Autowired
	private TheatreService service;

	@PostMapping("/addTheatre")
	public ResponseEntity<Theatre> addTheatre(@Valid @RequestBody Theatre theatre) {
		return new ResponseEntity<Theatre>(service.saveTheatre(theatre), HttpStatus.CREATED);
	}

	@GetMapping("/theatre")
	public ResponseEntity<Theatre> findTheatreByName(@Valid @RequestParam String name) {
		return new ResponseEntity<Theatre>(service.getTheatreByName(name), HttpStatus.OK);
	}

	@GetMapping("/theatre/{cityName}")
	public  ResponseEntity<List<Theatre>> findTheatreByCityName(@Valid @PathVariable String cityName) {
		return new ResponseEntity<List<Theatre>>(service.findTheatreByCityName(cityName), HttpStatus.OK);
	}

}
