package com.naveen.TheatreApi.Service;

import java.util.List;

import com.naveen.TheatreApi.Entity.Theatre;

public interface TheatreService {

	 Theatre saveTheatre(Theatre theatre);
	 
	 Theatre getTheatreByName(String name);
	 
	 List<Theatre> findTheatreByCityName(String cityName);


}
