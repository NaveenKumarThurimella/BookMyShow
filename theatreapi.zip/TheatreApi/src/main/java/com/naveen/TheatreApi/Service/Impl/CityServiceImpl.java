package com.naveen.TheatreApi.Service.Impl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.naveen.TheatreApi.Entity.City;
import com.naveen.TheatreApi.Repository.CityRepository;
import com.naveen.TheatreApi.Service.CityService;

@Service
public class CityServiceImpl implements CityService {

	@Autowired
	private CityRepository cRepo;
	
	@Override
	public City addCity(City city) {
		System.out.println("im here also");
		return cRepo.save(city);
	}

}
