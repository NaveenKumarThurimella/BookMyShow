package com.naveen.TheatreApi.Service.Impl;


import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.naveen.TheatreApi.Entity.Theatre;
import com.naveen.TheatreApi.Exception.DuplicateTheatreException;
import com.naveen.TheatreApi.Repository.TheatreRepository;
import com.naveen.TheatreApi.Service.TheatreService;

@Service
public class TheatreServiceImpl implements TheatreService {
	
	@Autowired
	private TheatreRepository repository;
	
	@Override
	public Theatre saveTheatre(Theatre theatre)  {
	Theatre t=repository.findByName(theatre.getName());
	if(t==null) {
		 return repository.save(theatre); 
	}
	else {
		throw new DuplicateTheatreException("Theatre already existed with name "+theatre.getName());
	}
	}
	@Override
	public Theatre getTheatreByName(String name){
		return repository.findByName(name);
	}
	@Override
	public List<Theatre> findTheatreByCityName(String cityName) {
		return repository.findTheatreByCityName(cityName);
	}
	
	

}
