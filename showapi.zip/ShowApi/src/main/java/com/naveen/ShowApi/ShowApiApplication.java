package com.naveen.ShowApi;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ShowApiApplication {

	public static void main(String[] args) {
		SpringApplication.run(ShowApiApplication.class, args);
	}

}
