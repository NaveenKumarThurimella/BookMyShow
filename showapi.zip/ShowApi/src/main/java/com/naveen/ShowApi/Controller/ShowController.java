package com.naveen.ShowApi.Controller;

import java.util.List;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.naveen.ShowApi.Entity.Show;
import com.naveen.ShowApi.Service.ShowService;

@RestController
public class ShowController {
	
	@Autowired
	private ShowService service;
	
	@PostMapping("/addShow")
	public Show addShow(@Valid @RequestBody Show show) {
		return service.saveShow(show);
	}
	
	@GetMapping("/show/{theatreid}")
	public ResponseEntity<List<Show>> getByMovieid(@Valid @PathVariable Integer theatreid)
	{
		return new ResponseEntity<List<Show>>(service.findByTheatreid(theatreid),HttpStatus.OK);
	}
	
}
