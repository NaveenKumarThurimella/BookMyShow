package com.naveen.ShowApi.Service.Impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.naveen.ShowApi.Entity.Show;
import com.naveen.ShowApi.Repository.ShowRepository;
import com.naveen.ShowApi.Service.ShowService;

@Service
public class ShowServiceImpl implements ShowService{
	
	@Autowired
	private ShowRepository repository;

	@Override
	public Show saveShow(Show show) {
		return repository.save(show);
	}

	@Override
	public List<Show> findByTheatreid(Integer theatreid) {
		return repository.findByTheatreid(theatreid);
	}

}
