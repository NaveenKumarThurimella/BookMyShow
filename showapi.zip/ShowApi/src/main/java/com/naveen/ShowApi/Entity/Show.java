package com.naveen.ShowApi.Entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

import lombok.AllArgsConstructor;
import lombok.NoArgsConstructor;

@NoArgsConstructor
@AllArgsConstructor
@Entity
@Table(name = "show")
public class Show {

	@Id
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "sid_generator")
	@SequenceGenerator(name = "sid_generator", initialValue = 1, allocationSize = 1, sequenceName = "sid_seq")
	@Column(name = "sid")
	private int sid;

	@Column(name = "show_name")
	private String name;

	@Column(name = "show_time")
	private String showtime;
	
	@Column(name="movie_id")
	private int movieid;
	
	@Column(name="screen_id")
	private int screenid;
	
	@Column(name="theatre_id")
	private int theatreid;

	public int getSid() {
		return sid;
	}

	public void setSid(int sid) {
		this.sid = sid;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getShowtime() {
		return showtime;
	}

	public void setShowtime(String showtime) {
		this.showtime = showtime;
	}

	public int getMovieid() {
		return movieid;
	}

	public void setMovieid(int movieid) {
		this.movieid = movieid;
	}

	public int getScreenid() {
		return screenid;
	}

	public void setScreenid(int screenid) {
		this.screenid = screenid;
	}

	public int getTheatreid() {
		return theatreid;
	}

	public void setTheatreid(int theatreid) {
		this.theatreid = theatreid;
	}

	
	
		
	}
		
