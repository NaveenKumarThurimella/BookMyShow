package com.naveen.ShowApi.Service;

import java.util.List;

import org.springframework.stereotype.Service;

import com.naveen.ShowApi.Entity.Show;

@Service
public interface ShowService {

	Show saveShow(Show show);
	
	List<Show> findByTheatreid(Integer theatreid); 

}
