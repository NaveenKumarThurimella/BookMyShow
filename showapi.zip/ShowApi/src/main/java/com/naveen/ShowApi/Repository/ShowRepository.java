package com.naveen.ShowApi.Repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.naveen.ShowApi.Entity.Show;

@Repository
public interface ShowRepository extends JpaRepository<Show, Integer> {
	
	List<Show> findByTheatreid(Integer theatreid); 
   
}
